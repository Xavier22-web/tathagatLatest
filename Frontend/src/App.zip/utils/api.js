// API utility functions with error handling

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

// Generic fetch wrapper with error handling
export const fetchWithErrorHandling = async (url, options = {}) => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    clearTimeout(timeoutId);
    
    if (error.name === 'AbortError') {
      throw new Error('Request timeout - backend server may be unavailable');
    }
    
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new Error('Cannot connect to backend server. Please check if the server is running.');
    }
    
    throw error;
  }
};

// Check if backend is available
export const checkBackendHealth = async () => {
  try {
    await fetchWithErrorHandling(`${API_BASE_URL}/api/health`);
    return true;
  } catch (error) {
    console.warn('Backend health check failed:', error.message);
    return false;
  }
};

// API endpoints
export const API_ENDPOINTS = {
  AUTO_LOGIN: `${API_BASE_URL}/api/v1/auto-login`,
  PUBLISHED_COURSES: `${API_BASE_URL}/api/courses/student/published-courses`,
  MY_COURSES: `${API_BASE_URL}/api/user/student/my-courses`,
  IIM_PREDICTOR: (userId) => `${API_BASE_URL}/api/v2/iim-predictor/${userId}`,
};
